module Minesweeper {
	requires java.desktop;
	requires java.sql;
}